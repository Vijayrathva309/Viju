Create & share photos, stories, & reels with friends you love

Little moments lead to big friendships. Share yours on Instagram. 
—From Meta

Connect with friends, find other fans, and see what people around you are up to and into. Explore your interests and post what's going on, from your daily moments to life's highlights.

Share what you’re up to and into on Insta®.
- Keep up with friends on the fly with Stories and Notes that disappear after 24 hours.
- Start group chats and share unfiltered moments with your Close Friends.
- Share memories from recent events or trips in Feed.
- Turn your life into a movie and discover short, entertaining videos on Instagram with Reels.
- Customize your posts with exclusive templates, music, stickers and filters.

Dive into your interests.
- Watch videos from your favorite Creators and discover new content that’s personalized to your interests.
- Get inspired by photos and videos from new accounts in Explore.
- Discover brands and small businesses, and shop products that are relevant to your personal style.

Some Instagram features may not be available in your country or region.
